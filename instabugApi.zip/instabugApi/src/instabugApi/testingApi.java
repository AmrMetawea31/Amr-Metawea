package instabugApi;

import static org.testng.Assert.assertEquals;

import org.hamcrest.CoreMatchers;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.matcher.ResponseAwareMatcher;
import io.restassured.response.Response;
public class testingApi {

	@Test
	public void checkStatusCode() {
		RestAssured.get("http://localhost:3030/products").then().assertThat().statusCode(200);
		
	}
	
	@Test
	public void getProductId() {
		Response response = RestAssured.get("http://localhost:3030/products/43900");
		String Data = response.getBody().asString();
		Assert.assertEquals(Data.contains("Duracell - AAA Batteries (4-Pack)"), true );
		
	}

	
	
}
